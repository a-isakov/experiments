package walking.game.player;
import walking.game.util.Direction;

public class Player {
    private int score;
    protected Direction direction;
    
    public int getScore(){
        return score;
    }

    public Player(){
        
    }
    protected Direction getDirection() {
        return direction;
    }
}

    

    