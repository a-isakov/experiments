package walking.game.util;

public enum Direction {
    UP, RIGHT, DOWN, LEFT;

    public Direction next() {
        if (this == UP) {
            return RIGHT;
        } else if (this == RIGHT) {
            return DOWN;
        } else if (this == DOWN) {
            return LEFT;
        } else {
            return UP;
        }
    }
}
