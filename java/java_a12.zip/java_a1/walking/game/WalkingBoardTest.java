package walking.game;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;
import walking.game.util.Direction;

public class WalkingBoardTest {
    @ParameterizedTest
    @ValueSource(ints = {1, 3})
    public void testSimpleInit(int size) {
        final var sub = new WalkingBoard(size);
        final var tiles = sub.getTiles();

        // getTiles shows suitable values.
        Assertions.assertEquals(size, tiles.length);
        for (var tAr : tiles) {
            Assertions.assertEquals(size, tAr.length);
            for (var t : tAr) {
                Assertions.assertEquals(WalkingBoard.BASE_TILE_SCORE, t);
            }
        }

        // The edges of the board (the smallest and biggest conceivable values) are accessible and contain the values that they have to (BASE_TILE_SCORE).
        Assertions.assertEquals(WalkingBoard.BASE_TILE_SCORE, sub.getTile(0, 0));
        Assertions.assertEquals(WalkingBoard.BASE_TILE_SCORE, sub.getTile(size - 1, size - 1));
    }

    @ParameterizedTest
    @CsvSource({"1,2,3"})
    public void testCustomInit(int x, int y, int expected) {
        final var origTiles =
                new int[][]{
                        new int[]{1, 2, 3},
                        new int[]{4, 5, 6},
                        new int[]{7, 8, 9},
                };
        for (int i = 0; i < origTiles.length; i++) {
            for (int j = 0; j < origTiles[i].length; j++) {
                final var v = origTiles[i][j];
                if (v < x || v < y || v < expected) {
                    origTiles[i][j] = WalkingBoard.BASE_TILE_SCORE - 1;
                }
            }
        }
        final var sub = new WalkingBoard(origTiles);
        final var tiles = sub.getTiles();
        // On positions where values smaller than three were passed, the board contains the value BASE_TILE_SCORE.
        for (int i = 0; i < tiles.length; i++) {
            for (int j = 0; j < tiles[i].length; j++) {
                final var v = origTiles[i][j];
                if (v < x || v < y || v < expected || v < WalkingBoard.BASE_TILE_SCORE) {
                    Assertions.assertEquals(WalkingBoard.BASE_TILE_SCORE, tiles[i][j]);
                } else {
                    Assertions.assertEquals(origTiles[i][j], tiles[i][j]);
                }
            }
        }

        // If you pass an array to the constructor and later modify a value in it, the respective tile retains the originally passed value.
        var oldV = tiles[0][0];
        origTiles[0][0] = oldV + 100;
        Assertions.assertEquals(oldV, sub.getTiles()[0][0]);

        //If you modify an element in the return value of getTiles(), and get the value of the respective tile again, this newly received content has to be the originally set value
        sub.getTiles()[0][0] += 100;
        Assertions.assertEquals(oldV, sub.getTiles()[0][0]);
    }

    @Test
    public void testMoves() {
        final var steps = 5;
        final var sub = new WalkingBoard(steps);
        final var value = WalkingBoard.BASE_TILE_SCORE - 1;

        final var tiles = sub.getTiles();

        for (int i = 0; i < steps - 1; i++) {
            sub.setAndMove(Direction.RIGHT, value);
        }
        sub.setAndMove(Direction.UP, value);


        for (int x = 0; x < tiles.length; x++) {
            for (int y = 0; y < tiles[x].length; y++) {
                if (y == 0) {
                    Assertions.assertEquals(value, sub.getTile(x, y));
                } else {
                    Assertions.assertEquals(tiles[x][y], sub.getTile(x, y));
                }
            }
        }
    }

    @Test
    public void testTryToMoveToCornerPos() {
        // Include a step that tries to move to the x coordinate Integer.MIN_VALUE

        final var sub = new WalkingBoard(667);
        final var pos = sub.getPosition();

        for (long i = pos[0]; i >= Integer.MIN_VALUE; i--) {
            sub.moveAndSet(Direction.LEFT, 1);
        }

        Assertions.assertEquals(sub.getPosition()[0], 0);

        // and another one that moves to the y coordinate 666.

        for (long i = pos[1]; i <= 666; i++) {
            sub.moveAndSet(Direction.UP, 0);
        }

        Assertions.assertEquals(sub.getPosition()[1], 666);

        // Include a step that tries to move outside of the board. In this case, check that both the position and the board’s contents are unchanged
        // move to left border
        for (long i = pos[0]; i > 0; i--) {
            sub.moveAndSet(Direction.LEFT, 1);
        }

        final var currentTiles = sub.getTiles();
        final var currentPos = sub.getPosition();
        // move to out of border
        sub.moveAndSet(Direction.LEFT, 1);
        Assertions.assertArrayEquals(currentPos, sub.getPosition());
        final var tiles = sub.getTiles();
        Assertions.assertEquals(currentTiles.length, tiles.length);
        for (int x = 0; x < tiles.length; x++) {
            Assertions.assertArrayEquals(currentTiles[x], tiles[x]);
        }
    }
}