package walking.game;

import walking.game.util.Direction;

import java.util.Arrays;

public class WalkingBoard {
    public static final int BASE_TILE_SCORE = 10;
    private int[][] tiles;

    private int x, y;

    public WalkingBoard(int size) {
        tiles = new int[size][];
        for (int i = 0; i < size; i++) {
            tiles[i] = new int[size];
            Arrays.fill(tiles[i], BASE_TILE_SCORE);
        }
    }

    public WalkingBoard(int[][] tiles) {
        this.tiles = Arrays.stream(tiles)
                .map(tilesAr ->
                        Arrays.stream(tilesAr)
                                .map(tile -> Math.max(BASE_TILE_SCORE, tile))
                                .toArray()
                )
                .toArray(int[][]::new);
    }

    public int[][] getTiles() {
        return Arrays.stream(tiles).map(tilesAr -> Arrays.copyOf(tilesAr, tilesAr.length)).toArray(int[][]::new);
    }

    public int getTile(int x, int y) {
        if (!isValidPosition(x, y)) {
            throw new IllegalArgumentException("Invalid position x:[%d] y:[%d]".formatted(x, y));
        }
        return tiles[x][y];
    }

    public static int getXStep(Direction direction) {
        switch (direction) {
            case RIGHT:
                return 1;
            case LEFT:
                return -1;
            default:
                return 0;
        }
    }

    public static int getYStep(Direction direction) {
        switch (direction) {
            case UP:
                return 1;
            case DOWN:
                return -1;
            default:
                return 0;
        }
    }

    public boolean isValidPosition(int x, int y) {
        return x >= 0 && x < tiles.length
                && y >= 0 && y < tiles[x].length;
    }

    public int moveAndSet(Direction direction, int value) {
        final int newX = x + getXStep(direction);
        final int newY = y + getYStep(direction);

        if (!isValidPosition(newX, newY)) {
            return 0;
        }

        final int oldValue = tiles[newX][newY];
        x = newX;
        y = newY;
        tiles[newX][newY] = value;

        return oldValue;
    }

    public int setAndMove(Direction direction, int value) {
        final int newX = x + getXStep(direction);
        final int newY = y + getYStep(direction);

        if (!isValidPosition(newX, newY)) {
            return 0;
        }

        final int oldValue = tiles[newX][newY];
        tiles[x][y] = value;
        x = newX;
        y = newY;

        return oldValue;
    }

    public int[] getPosition() {
        return new int[]{x, y};
    }
}
