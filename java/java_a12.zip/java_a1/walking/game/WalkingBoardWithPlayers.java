package walking.game;

import walking.game.player.MadlyRotatingBuccaneer;
import walking.game.player.Player;

public class WalkingBoardWithPlayers extends WalkingBoard {
    private Player[] players;
    private int round;
    public static final int SCORE_EACH_STEP = 0;

    public WalkingBoardWithPlayers(int[][] board, int playerCount) {
        super(board);

        initPlayers(playerCount);

    }

    public WalkingBoardWithPlayers(int size, int playerCount) {
        super(size);
        initPlayers(playerCount);
    }

    public int[] walk(int... stepCounts) {
        return null;
    }

    private void initPlayers(int playerCount) {
        if (playerCount < 2) {
            throw new IllegalArgumentException("Players count [%d] less than 2".formatted(playerCount));
        }
        players = new Player[playerCount];
        players[0] = new MadlyRotatingBuccaneer();
        for (int i = 1; i < playerCount; i++) {
            players[i] = new Player();
        }
    }
}
