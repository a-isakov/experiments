package walking.game.player;

import walking.game.util.Direction;

public class Player {

    protected static final Direction INIT_DIRECTION = Direction.UP;

    private int score;
    protected Direction direction;

    public Player() {

    }

    public int getScore() {
        return score;
    }

    public Direction getDirection() {
        return direction;
    }

    public void turn() {
        if (direction == null) {
            direction = INIT_DIRECTION;
        } else {
            direction = direction.next();
        }
    }

    public void addToScore(int score) {
    }
}

    

    