package walking.game.player;

public class MadlyRotatingBuccaneer extends Player {
    private int turnCount;

    public MadlyRotatingBuccaneer() {
        super();

        direction = INIT_DIRECTION;
    }

    public void turn() {
        if(turnCount == 0) {
            turnCount++;
            super.turn();
        } else {
            turnCount += 2;
            super.turn();
            super.turn();
        }
    }
}