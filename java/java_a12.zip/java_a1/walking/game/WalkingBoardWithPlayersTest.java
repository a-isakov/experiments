package walking.game;

import org.junit.jupiter.api.Test;

public class WalkingBoardWithPlayersTest {
    @Test
    public void test() {
    }
}
